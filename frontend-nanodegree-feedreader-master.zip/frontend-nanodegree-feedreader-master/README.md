# Project Overview

To use this project, You must clone/download this resource.
Once you have got the resource, Open index.html and it will load.
scroll to the bottom of the page and you will see jasmine.
It will shows the tests run.
